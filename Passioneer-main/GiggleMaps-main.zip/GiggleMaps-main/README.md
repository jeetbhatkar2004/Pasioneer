Giggle Maps: Google Maps for a better world

https://devpost.com/software/gigglemaps-ebnzh0