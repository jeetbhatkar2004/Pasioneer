import streamlit as st
# import streamlit.components.v1 as components

# with open('index.html') as f:
#     render_html = f.read()
    
# components.html(render_html)

st.title("Getting Started")
st.text("Pick one of the activities from the sidebar")
st.text("Drums | Guitar | Workout | Yoga")

